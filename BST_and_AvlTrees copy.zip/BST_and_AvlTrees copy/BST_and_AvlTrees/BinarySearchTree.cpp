#include <iostream>
#include <string>
#include "BinarySearchTree.h"
#include <chrono>

using namespace std;
using namespace std::chrono;

long BinarySearchTree::probe_count = 0;
long BinarySearchTree::comparison_count = 0;
long BinarySearchTree::elapsed_time = 0;

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() : root(nullptr)
{
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree()
{
    clear();
}

/**
 * Getter.
 * @return pointer to the root of the tree.
 */
BinaryNode *BinarySearchTree::getRoot() const { return root; }

/**
 * Public member function to return the height of a subtree.
 * @return the height.
 */
int BinarySearchTree::height() const { return height(root); }

/**
 * Protected member function to compute the height of a subtree.
 * @param ptr pointer to the root node of the subtree.
 * @return the height.
 */
int BinarySearchTree::height(const BinaryNode *ptr) const
{
    /***** Complete this function. *****/
    
    if (ptr == nullptr)
    {
        return -1;
    }
    else
    {
        return max(height(ptr->left), height(ptr->right)) + 1;
    }
}

/**
 * Public member function to find the minimum data item in a subtree.
 * @return the minimum data item in the tree
 *         or nullptr if the tree is empty.
 * @throw a string message if an error occurred.
 */
long BinarySearchTree::findMin() const throw(string)
{
    if (isEmpty()) throw(string("Empty tree"));
    return findMin(root)->data;
}

/**
 * Private member function to find the minimum data item in a subtree.
 * @param ptr pointer to the root node of the subtree.
 * @return pointer to the node containing the smallest data item
 *         or nullptr if the subtree is empty.
 */
BinaryNode *BinarySearchTree::findMin(BinaryNode *ptr) const
{
    /***** Complete this function. *****/
    BinaryNode* current = ptr;
    
    while (current->left != NULL)
    {
        current = current->left;
    }
    return current;
}

/**
 * Public member function to find the maximum data item in a subtree.
 * @return pointer to the maximum data item in the tree
 *         or nullptr if the tree is empty.
 * @throw a string message if an error occurred.
 */
long BinarySearchTree::findMax() const throw(string)
{
    if (isEmpty()) throw(string("Empty tree"));
    return findMax(root)->data;
}

/**
 * Private member function to find the maximum data item in a subtree.
 * @param ptr pointer to the root node of the subtree.
 * @return pointer to the node containing the largest data item
 *         or nullptr if the subtree is empty.
 */
BinaryNode *BinarySearchTree::findMax(BinaryNode *ptr) const
{
    /***** Complete this function. *****/
    BinaryNode *current = ptr;
    
    while (current-> right != NULL)
    {
        current = current->right;
    }
    return current;
}

/**
 * Public member function to empty a subtree.
 */
void BinarySearchTree::clear()
{
    clear(root);
}

/**
 * Private member function to empty a subtree.
 * @param ptr pointer to the root node of the subtree.
 */
void BinarySearchTree::clear(BinaryNode* &ptr)
{
    /***** Complete this function. *****/
    
    if (ptr != nullptr)
    {
        clear(ptr->left);
        clear(ptr->right);
        delete ptr;
        ptr = nullptr;
    }
}

/**
 * Is the tree empty?
 * @return true if and only if the tree is empty.
 */
bool BinarySearchTree::isEmpty() const
{
    return root == nullptr;
}

/**
 * Public member function to search for a data item in the tree.
 * @param data the data to search for.
 * @return true if and only if data is in the tree.
 */
bool BinarySearchTree::contains(const long data) const
{
    return contains(data, root);
}

/**
 * Private member function to search for a data item in a subtree.
 * @param data the data to search for.
 * @param ptr pointer to the root node of the subtree.
 * @return true if and only if data is in the tree.
 */
bool BinarySearchTree::contains(const long data, BinaryNode *ptr) const
{
    /***** Complete this function. *****/
    
    
    while (ptr != nullptr)
    {
        probe_count++;
        if (data < ptr->data)
        {
            comparison_count++;
            ptr = ptr->left;
        }
        else if (data > ptr->data)
        {
            comparison_count++;
            ptr = ptr->right;
        }
        else
        {
            return true;
        }
    }
    
    return false;
}

/**
 * Public member function to insert a data item into a subtree
 * and set the new root of the subtree.
 * @param data the data to insert into the tree.
 */
void BinarySearchTree::insert(const long data)
{
    steady_clock::time_point start_time = steady_clock::now();
    insert(data, root);
    steady_clock::time_point end_time = steady_clock::now();
    elapsed_time += duration_cast<microseconds>(end_time - start_time).count();    
}

/**
 * Protected member function to insert a data item into a subtree
 * and set the new root of the subtree.
 * @param data the data to insert.
 * @param ptr pointer to the root node of the subtree.
 */
void BinarySearchTree::insert(const long data, BinaryNode* &ptr)
{
//        cout << "=== Insert called on "
//             << (ptr != nullptr ? to_string(ptr->data) : "null")
//             << endl;
    
    /***** Complete this function. *****/
    
    probe_count++;
    if (ptr == nullptr)
    {
        comparison_count++;
        ptr = new BinaryNode(data);
    }
    else
    {
        comparison_count++;
        if (data == ptr->data)
        {
            comparison_count++;
            return;
        }
        else
        {
            probe_count++;
            comparison_count++;
            if (data < ptr->data)
            {
                comparison_count++;
                insert(data, ptr->left);
            }
            else
            {
                comparison_count++;
                if (data > ptr->data)
                {
                    comparison_count++;
                    insert(data, ptr->right);
                }
            }
        }
    }
}

/**
 * Public member function to remove a data item from a subtree
 * and set the new root of the subtree.
 * Do nothing if the data item is not found.
 * @param data the data to remove.
 */
void BinarySearchTree::remove(const long data)
{
    remove(data, root);
}

/**
 * Protected member function to remove a data item from a subtree
 * and set the new root of the subtree.
 * Do nothing if the data item is not found.
 * @param data the data to remove.
 * @param ptr pointer to the root node of the subtree.
 * Reference : Ron Mak Class Slides
 */
void BinarySearchTree::remove(const long data, BinaryNode* &ptr)
{
//        cout << "=== Remove called on "
//             << (ptr != nullptr ? to_string(ptr->data) : "null")
//             << endl;
    
    /***** Complete this function. *****/
    
    if(ptr == nullptr)
    {
        return;
    }
    else if (data < ptr->data)
    {
        remove(data, ptr->left);
    }
    else if (data > ptr->data)
    {
        remove(data, ptr->right);
    }
    else if (   (ptr->left  != nullptr)
             && (ptr->right != nullptr))
    {
        ptr->data = findMin(ptr->right)->data;
        remove(ptr->data, ptr->right);
    }
    else
    {
        BinaryNode *oldNode = ptr;
        ptr = (ptr->left != nullptr) ? ptr->left
        : ptr->right;
        delete oldNode;
    }    
}
/*
 * Public getter function
 * @return the probe_count private member value
 */
long BinarySearchTree::get_probe_count() const
{
    return probe_count;
}

/*
 * Public getter function
 * @return the comparison_count private member value
 */
long BinarySearchTree::get_comparison_count() const
{
    return comparison_count;
}

/*
 * Public getter function
 * @return the elapsed time private member value
 */
long BinarySearchTree::get_elapsed_time() const
{
    return elapsed_time;
}

void BinarySearchTree::set_elapsed_time(long val)
{
    elapsed_time = val;
}

void BinarySearchTree::reset()
{
    probe_count = 0;
    elapsed_time = 0;
    comparison_count = 0;
}

