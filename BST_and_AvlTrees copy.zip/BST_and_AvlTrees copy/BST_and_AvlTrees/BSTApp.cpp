/**
 * Test the binary search tree and AVL tree implementations.
 * The AVL tree is derived from the binary search tree.
 *
 * Create a tree of height 5 and then repeatedly
 * delete the root. The AVL tree should remain balanced
 * after each node insertion and deletion.
 *
 * Author: Ron Mak
 *         Department of Computer Engineering
 *         San Jose State University
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <time.h>
#include <chrono>

#include "BinarySearchTree.h"
#include "AvlTree.h"

using namespace std;
using namespace std::chrono;

//const bool DUMP = false;

void testBST();
void testAVL();

void buildTree(BinarySearchTree& tree, int size);

void searchTree(BinarySearchTree& tree, int size);

void output_tree_stats(BinarySearchTree& tree);

string commafy(long n);

/**
 * Main.
 */
int main( )
{
    testBST();
    testAVL();
}


void testBST()
{
    cout << endl;
    cout << "**********************" << endl;
    cout << "* BINARY SEARCH TREE *" << endl;
    cout << "**********************" << endl;
    
    BinarySearchTree  tree;
    
    cout << "------------------------" << endl;
    cout << "INSERTIONS - PERFORMANCE" << endl;
    cout << "------------------------" << endl << endl;
    
    cout << endl << "N  " ;
    cout << setw(25) << "PROBE COUNTS" << setw(20) << "COMPARE COUNTS"
    << setw(30) << "ELAPSED TIME (µs)" << endl <<endl;
    
    for (int n = 10000; n <= 100000; n += 10000)    {
        
        cout <<setw(7) <<commafy(n);
        tree.reset();
        buildTree(tree, n);
        
        
        
    }
    cout << "--------------------" << endl;
    cout << "SEARCH - PERFORMANCE" << endl;
    cout << "--------------------" << endl << endl;
    
    cout << endl << "N  " ;
    cout << setw(25) <<"PROBE COUNTS" << setw(20) << "COMPARE COUNTS"
    << setw(30) << "ELAPSED TIME (µs)" << endl <<endl;
    
    for (int n = 10000; n <= 100000; n += 10000)
    {
//        cout << endl << "N = " << commafy(n) << endl << endl;
//        cout << setw(20) <<"PROBE COUNTS" << setw(20) << "COMPARE COUNTS"
//        << setw(30) << "ELAPSED TIME (µs)" << endl;
        
        cout <<setw(7) << commafy(n) ;
        tree.reset();
        searchTree(tree, n);
    }
}


void testAVL()
{
    cout << endl;
    cout << "************" << endl;
    cout << "* AVL TREE *" << endl;
    cout << "************" << endl;
    
    AvlTree tree;
    
    cout << "------------------------" << endl;
    cout << "INSERTIONS - PERFORMANCE" << endl;
    cout << "------------------------" << endl << endl;
    cout << endl << "N";
    cout <<setw(25) << "PROBE COUNTS " << setw(20) << "COMPARE COUNTS"
    << setw(30) << "ELAPSED TIME (µs)" << endl <<endl;
    
    for (int n = 10000; n <= 100000; n += 10000)
    {
        
        cout <<setw(7) <<commafy(n);
        tree.reset();
        buildTree(tree, n);    
        
    }
    
    cout << "--------------------" << endl;
    cout << "SEARCH - PERFORMANCE" << endl;
    cout << "--------------------" << endl << endl;
    cout <<endl <<"N";
    cout << setw(25) << "PROBE COUNTS" << setw(20) << "COMPARE COUNTS"
    << setw(30) << "ELAPSED TIME (µs)" << endl <<endl;
    
    for (int n = 10000; n <= 100000; n += 10000)
    {
        
        cout <<setw(7) <<commafy(n);
        tree.reset();
        searchTree(tree, n);
    }
}


void buildTree(BinarySearchTree& tree, int input_size)
{
    srand(time(NULL));  // seed the random number generator
    
    for (int i = 1; i < input_size; i++)
    {
        int r = rand() % input_size;
        tree.insert(r);
    }
    
    output_tree_stats(tree);
}


void searchTree(BinarySearchTree& tree, int input_size)
{
    srand(time(NULL));  // seed the random number generator
    
    for (int i = 1; i < input_size; i++)
    {
        int r = rand() % input_size;
        
        steady_clock::time_point start_time = steady_clock::now();
        
        tree.contains(r);
        
        steady_clock::time_point end_time = steady_clock::now();
        tree.set_elapsed_time(tree.get_elapsed_time() + duration_cast<microseconds>(end_time - start_time).count());
    }
    
    output_tree_stats(tree);
}

/**
 * Output BST or AVL tree's probe and comparison counts and elapsed time.
 * @param tree whose statistics needs to be printed.
 */
void output_tree_stats(BinarySearchTree& tree)
{
    cout << setw(20) << commafy(tree.get_probe_count());
    cout << setw(20) << commafy(tree.get_comparison_count());
    cout << setw(20) << commafy(tree.get_elapsed_time());
    cout << endl << endl;
}

/**
 * Convert a number to a string with commas.
 * @param n the number.
 */
string commafy(long n)
{
    string str = to_string(n);
    int pos = str.length() - 3;
    
    while (pos > 0)
    {
        str.insert(pos, ",");
        pos -= 3;
    }
    
    return str;
}
