#ifndef NODE_H_
#define NODE_H_

#include "Element.h"

/**
 * A node of the linked list for mergesort.
 */
class Node
{
public:
    /***** Complete this class. *****/
    
    /*
     * Default constructor
     */
    Node ();
    
    /*
     * Single Paramter constructor
     * @param element the element to construct the Node
     */
    Node (Element element);
    
    long get_value();
    
    Element element;
    Node *next;
};

#endif /* NODE_H_ */

