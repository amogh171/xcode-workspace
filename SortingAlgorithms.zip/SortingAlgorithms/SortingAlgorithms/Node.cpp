#include "Node.h"
#include "Element.h"

/***** Complete this class. *****/

Node::Node() : next(nullptr) {}

Node::Node (Element temp)
{
    element = temp;
    next = nullptr;
}

long Node::get_value()
{
    return element.get_value();
}


