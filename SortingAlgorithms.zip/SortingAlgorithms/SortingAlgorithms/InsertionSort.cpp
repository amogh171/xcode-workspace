#include "InsertionSort.h"

/**
 * Constructor.
 * @param name the name of the algorithm.
 */
InsertionSort::InsertionSort(string name) : VectorSorter(name) {}

/**
 * Destructor.
 */
InsertionSort::~InsertionSort() {}

/**
 * Run the insertion sort algorithm.
 * @throws an exception if an error occurred.
 * Reference : http://www.geeksforgeeks.org/insertion-sort/
 */
void InsertionSort::run_sort_algorithm() throw (string)
{
    /***** Complete this member function. *****/    
    
    Element key;
    for (int i = 1; i < size; i++)
    {
        key = data[i];
        int j = i-1;

        /* Move elements of data[0..i-1], that are
         greater than key, to one position ahead
         of their current position */
        while (j >= 0 && data[j] > key)
        {
            compare_count++;
            move_count++;
            data[j+1] = data[j];
            j = j-1;
        }
        move_count++;
        data[j+1] = key;
    }
}

