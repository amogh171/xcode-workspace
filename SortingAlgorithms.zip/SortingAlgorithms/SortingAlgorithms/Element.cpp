#include <iostream>
#include "Element.h"

using namespace std;

/***** Complete this class. *****/

int Element::copy_count = 0;
int Element::destructor_count = 0;

/**
 * Default constructor.
 */
Element::Element() : value(0) {}

/**
 * Constructor.
 * @param val the element's value.
 */
Element::Element(long val) : value(val) {}

/**
 * Copy constructor.
 * @param other the other element to be copied.
 */
Element::Element(const Element& other)
{
    /***** Complete this class. *****/
    value = other.value;
    copy_count++;
}

/*
 * overloaded output stream operator
 */
ostream& operator <<(ostream& outs, const Element& elmt)
{
    outs <<elmt.value;
    return outs;
}
/*
 * overloaded > operator
 */
bool Element::operator >(Element& elmt)
{
    return value > elmt.value;
}

/*
 * overloaded < operator
 */
bool Element::operator <(Element& elmt)
{
    return value < elmt.value;
}

/*
 * resets copy_count and destructor_count to 0
 */
void Element::reset()
{
    copy_count = 0;
    destructor_count = 0;
}

/*
 * getter
 * @return the copy_count value
 */
int Element::get_copy_count() { return copy_count; }

/*
 * getter
 * @return the destuctor_count value
 */
int Element::get_destructor_count() { return destructor_count; }

/**
 * Destructor.
 */
Element::~Element()
{
    /***** Complete this class. *****/
    destructor_count++;
}

/**
 * Getter.
 * @return the value.
 */
long Element::get_value() const { return value; }

