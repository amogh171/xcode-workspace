#ifndef DATA_H_
#define DATA_H_

#include <iostream>
using namespace std;

/**
 * The class for the data elements that will be sorted.
 */
class Element
{
public:
    Element();
    Element(long val);
    Element(const Element& other);
    virtual ~Element();
    
    long get_value() const;
    
    friend ostream& operator <<(ostream& outs, const Element& elmt);
    
    bool operator >(Element& elmt);
    
    bool operator <(Element& elmt);
    
    static void reset();
    
    static int get_destructor_count();
    
    static int get_copy_count();
    
    /***** Complete this class. *****/
    
private:
    long value;
    static int copy_count;
    static int destructor_count;
};

#endif /* DATA_H_ */

