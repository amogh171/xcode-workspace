#include "ShellSortOptimal.h"

/**
 * Constructor.
 * @param name the name of this algorithm.
 */
ShellSortOptimal::ShellSortOptimal(string name) :VectorSorter(name) {}

/**
 * Destructor.
 */
ShellSortOptimal::~ShellSortOptimal() {}

/**
 * Run the optimal shellsort algorithm.
 * According to Don Knuth:
 * h = 3*i + 1 for i = 0, 1, 2, ... used in reverse.
 * @throws an exception if an error occurred.
 * Reference: ftp://ftp.cs.princeton.edu/pub/cs226/linksort/shellsort.c
 */
void ShellSortOptimal::run_sort_algorithm() throw (string)
{
    /***** Complete this member function. *****/
    
//    //int h = 1;
//    int done; //flag to stop pass early if no exchanges
//
//    // determine the initial increment sequence h
//    int initial_gap;
//    for (initial_gap = 1; initial_gap <= size/3 ; initial_gap = 3*initial_gap + 1);
//
//    for(int h = initial_gap; h>=1; h /= 3)
//    {
//        done = 0;
//        while (done != 1)
//        {
//            done = 1;
//            for (int i = size - 1; i >= h; i--)
//            {
//                compare_count++;
//                if (data[i] < data[i-h])
//                {
//                    swap(i,i-h);
//                    done = 0;
//                }
//            }
//        }
//
//    }
    
    int initial_gap;
    for (initial_gap = 1; initial_gap < size ; initial_gap = 3*initial_gap + 1);
    
    // inital gap of elements is size/2
    for (int gap = initial_gap; gap >= 1; gap /= 3)
    {
        // Do a gapped insertion sort for this gap size.
        // The first gap elements a[0..gap-1] are already in gapped order
        // keep adding one more element until the entire array is
        // gap sorted
        for (int i = gap; i < size; i += 1)
        {
            // add a[i] to the elements that have been gap sorted
            // save a[i] in temp and make a hole at position i
            Element temp = data[i];
            
            // shift earlier gap-sorted elements up until the correct
            // location for a[i] is found
            int j;
            for (j = i; j >= gap && data[j - gap] > temp; j -= gap)
            {
                compare_count ++;
                data[j] = data[j - gap];
            }
            
            //  put temp (the original a[i]) in its correct location
            data[j] = temp;
        }
    }
    
}

